//---------------------------------------------------------------------------

#ifndef labH
#define labH
#include <fstream>
#include <sstream>
#include <iomanip>
const int tt=15;

class data {
public:
	 double mean, sd;
        data(double a=0.):mean(a),sd(a){}
        ~data(){}
};

template<size_t N> class Metab{
protected:
      const int len;
      bool flag;
      double fc,tcon, calc[N+2], kinc[tt],kinm0[tt];
public:
	double *iso, *diso;
	int ny;
 double* getcalc(){return &calc[0];}
	
 double percent(const int riht=0,const int left=0){
		double tot=0.; int nc,sum1;
		for(int i=0;i<N+2;i++) calc[i]=0.;
   for(nc=0;nc<len;nc++) {
    int i=((nc>>riht)&((len>>left>>riht)-1)); sum1=0;
	while(i>0){sum1 += (i & 1);i = (i >> 1);}
			calc[sum1] += iso[nc];
		}//end for
	for(int i=0;i<=N;i++) tot += calc[i];
//	for(int i=0;i<=N;i++) calc[i] /= tot;
		return calc[N+1]=tot;
	}
	
 void skladc(int itime){  kinc[itime]=calc[N+1]; }
 
 void skladm0(int itime){ kinm0[itime]=calc[0]/calc[N+1]; }
 
double sumt(){
		double sum=0.; unsigned i;
		for (i=0;i<len;i++) sum += iso[i];
		return calc[N+1]=sum;
	}
double input(Metab& s2,const double& vi,const double& vo){
		double x, sum=0.;
		for(int i=0;i<len;i++) {
			x=(vi*(iso[i])-vo*(s2.iso[i]));
			diso[i] -= x; s2.diso[i] += x; sum += x;
		}
	return sum;}
void output(const double& vi){
		double x, sum=0.;
		for(int i=0;i<len;i++) {
			x=vi*iso[i];	diso[i] -= x;}
	}
void set0(const double& s0){
		iso[0]=s0;
		for(int i=1;i<len;i++) iso[i]=0.;
	}
int getlen() const {return len;	}
double* getisot() {return iso;	}

void showsum(Metab<N>& s2,std::ostringstream& fo){
   fo<<" "<<std::setw(7)<<(this->calc[0]+s2.calc[0])/(this->calc[N+1]+s2.calc[N+1]);
}
void showm0(std::ostringstream& fo){
   fo<<" "<<std::setw(7)<<(this->calc[0]/this->calc[N+1]);
}

void showcon(std::ostringstream& fo){
  fo<<" "<<std::setw(7)<<this->calc[N+1];
}

void coriso(const double xkin,const double xiso){
 double ff=xkin/xiso;
  for(int i=0;i<len;i++) iso[i] *= ff;
  }

	void wcalc(std::ofstream& fi) {
	unsigned k;
	percent();
		for (k=0;k<(N+2);k++) 
       if((N+1)-k) fi<<"m"<<k<<" "<<calc[k]/calc[N+1]<<std::endl;
         else fi<<"conc: "<<calc[k]/calc[N+1]<<std::endl; 
			}
double cutfirst(Metab<(N-1)>& p,const double& v) {
		double dx, sum=0.;
		int i=0,i1;
		int lenp=((len>>1)-1);
		for(int i=0;i<this->len;i++) {i1 = (i & lenp);
			dx = v*(this->iso[i]);
		this->diso[i] -= dx; p.diso[i1] += dx; sum += dx;
		}
	return sum;}
	

	void volume(double factor) {
	for (int i=0; i<len;i++) diso[i] *= factor;
	}
	void carb (Metab<(N+1)>& pr,const double& v){
		int ipr; double dx;
		for(int i=0;i<this->len;i++) {
			dx = v*(this->iso[i]);
			this->diso[i] -= dx;
		ipr=(i<<1);		pr.diso[ipr] += dx;
		}
	}
	void decarb (Metab<(N-1)>& pr,const double& v) {
		int i,ipr; double dx;
		for(i=0;i<this->len;i++) {
			dx = v*(this->iso[i]);
			this->diso[i] -= dx;
		ipr=(i>>1);		pr.diso[ipr] += dx;
		}
	}
	void icdh (Metab<(N-1)>& pr,const double& v) {
		int i,ipr; double dx;
		for(i=0;i<this->len;i++) {
			dx = v*(this->iso[i]);
			this->diso[i] -= dx;
		ipr=((i&7)|((i>>1)&24)); pr.diso[ipr] += dx;
		}
	}
	void icdhr (Metab<(N+1)>& pr,const double& v) {
		int i,ipr; double dx;
		for(i=0;i<this->len;i++) {
			dx = v*(this->iso[i]);
			this->diso[i] -= dx;
		ipr=((i&7)|((i&24)<<1)); pr.diso[ipr] += dx;
		}
	}
	double liase (Metab<(N-2)>& pr,Metab<2>& ac,const double& v) {
		int i,ipr; double dx, sum=0.;
		for(i=0;i<this->len;i++) {
			dx = v*(this->iso[i]);
			this->diso[i] -= dx;
		ipr=(i&15); pr.diso[ipr] += dx;
		ipr=(i>>4); ac.diso[ipr] += dx; sum += dx;
		}
	return sum;}
       void sett(){ tcon= this->sumt();}
        double getcon() const {return tcon;}
        
	Metab():len(1<<N) {} //
	virtual ~Metab(){}
};

template<size_t N> class Metab_data:public Metab<N> {
  data conc[tt], exper[tt][N+1];
  double xicon[tt], xi[tt];
  int mi;
  std::string descr;
	public:
void read(std::ifstream& fi,int nt){
	unsigned i,j(0); std::string aaa;//i: isotopomer; j: time
                fi >> descr >> mi;
    while(j<(nt-1)) {
   fi>>j>>aaa; for(i=0;i<mi;i++) fi>>exper[j][i].mean;
   for(i=0;i<mi;i++) {fi>>exper[j][i].sd; if(exper[j][i].sd<0.01) exper[j][i].sd=0.01;}
      }// std::cout<<descr<<" "<<exper[nt-1][mi-1].mean<<std::endl;
	}
void readc(std::ifstream& fi,  int nt){ std::string aaa;
     fi>>aaa;
     for(int i=0;i<nt;i++) fi>>conc[i].mean;
     for(int i=0;i<nt;i++) {fi>>conc[i].sd; if(conc[i].sd<0.01) conc[i].sd=0.01;}
	}

data * getconc(){return conc;}
void setconc(double a){ conc[0].mean=a;}
data * getexper(int nt){return &exper[nt][0];}

void showmi(std::ostringstream& fo,int nt){
   for (int k=0;k<=N;k++) fo<<" "<<std::setw(7)<<(this->calc[k]/this->calc[N+1]); fo<<"\n";
   fo<<"Data";for (int k=0;k<=N;k++) fo<<" "<<std::setw(7)<<exper[nt][k].mean; fo<<"\n";
}

double chisq(int nt,int nl=N+1, double add=0.,double a0=0.) {
	double a, b=this->calc[N+1]+add, b0=this->calc[0]+a0;
	 xi[nt]=0; 
	if(exper[nt][0].sd>1.e-5){
     a=(exper[nt][0].mean-b0/b)/(exper[nt][0].sd); xi[nt] += a*a;
for(int k=1;k<nl;k++) {
     a=(exper[nt][k].mean-this->calc[k]/b)/(exper[nt][k].sd); xi[nt] += a*a;
     } }
return xi[nt];}
double chisqsum(Metab<N>& s2,int nt,int nl=N+1) {
	double a, b=this->calc[N+1]+s2.getcalc()[N+1];
	 xi[nt]=0; 
  if(exper[nt][0].sd>1.e-5) for(int k=0;k<nl;k++) {
     a=(exper[nt][k].mean-(this->calc[k]+s2.getcalc()[k])/b)/(exper[nt][k].sd); xi[nt] += a*a;
     }
return xi[nt];}

double chicon(int nt) {
	double a;
     a=(conc[nt].mean-this->calc[N+1])/(conc[nt].sd);
return (xicon[nt]=a*a);}

void wrikinc(std::string descr, std::ostringstream& so, int nt) {
    if(conc[nt-1].mean>1.e-5){
    so<<descr<<"_c: ";
      for(int i=0;i<nt;i++) so<<std::setw(9)<<this->kinc[i]; so<<"** "<<conc[nt-1].mean<<" -> "<<xicon[nt-1]<<std::endl;
 } }
void wrikinm0(std::string descr, std::ostringstream& so, int nt) { so.precision(3);
   if(exper[nt-1][0].sd>1.e-5){ 
      so<<descr<<"_m0: ";
     for(int i=0;i<nt;i++) so<<std::setw(9)<<this->kinm0[i]; so<<" * "<<exper[nt-1][0].mean<<" -> "<<xi[nt-1]<<std::endl;
 } }

	Metab_data(){}
	~Metab_data(){}
};

template<size_t N> class ketose:public Metab<N> {
 public:
        double ta123[8],tk12[4];
double dilut(double& dlt,data exper[],const int riht=0,const int left=0) {
	     unsigned i; double xi(0.0),a(0.0);
	   this->percent( riht, left);
	dlt = (exper[0].mean-this->calc[0])/(1.-exper[0].mean);
		if(dlt>0) {
		this->calc[0] += dlt;
		for(i=0;i<=N;i++) this->calc[i] /= (1.+dlt);this->calc[N+1] *= (1.+dlt);
		}
		for(i=0;i<(N+2);i++) {    //          for(int i=1;i<repl;i++)
			a = (exper[i].mean-this->calc[i])/(exper[i].sd);
			xi += a*a;
		}
		return xi;
	}
        void sett(){
		int i;
		for (i=0;i<8;i++) ta123[i]=0.;
		for (i=0;i<4;i++) tk12[i]=0.;
		int lena=(N-3);
		for (i=0;i<this->len;i++) ta123[i>>lena] += this->iso[i];
		for (i=0;i<8;i++) tk12[i>>1] += ta123[i];
		this->tcon=0; for (i=0;i<4;i++) this->tcon += tk12[i];
//		this->tcon= this->sumt();
		for (i=0;i<8;i++) ta123[i] /= this->tcon;
		for (i=0;i<4;i++) tk12[i] /= this->tcon;
	}
void invistk(Metab<N-2>& ald,const double v) {   
  int i,ii,j, ik,ib,lena=this->len>>2;
   double x,vk, va,sumx=0;
    const double *pak;
       pak=&this->tk12[0]; ib=4;
	vk=v/this->getcon();
   for(j=0;j<ib;j++){
     for(i=0;i<lena;i++) {ii=(i + j*lena);
 	x=this->iso[ii]*vk;
          sumx +=x;
         this->diso[ii] -= x;
          ald.diso[i] += x; }	
    }
     va= sumx/ald.getcon();
     for(j=0;j<lena;j++) {
          x= va*(ald.iso[j]);
            ald.diso[j] -= x;
        for (i=0;i<ib;i++) {
             ik=(j + i*lena);
                this->diso[ik] += x*pak[i];}
       }
}
void invista(Metab<N-3>& ald,const double v) {   
  int i,ii,j, ik,ib,lena=this->len>>3;
   double x,vk, va,sumx=0;
    const double *pak;
       pak=&this->ta123[0]; ib=8;
	vk=v/this->getcon();
   for(j=0;j<ib;j++){
     for(i=0;i<lena;i++) {ii=(i + j*lena);
 	x=this->iso[ii]*vk;
          sumx +=x;
         this->diso[ii] -= x;
          ald.diso[i] += x; }	
    }
     va= sumx/ald.getcon();
     for(j=0;j<lena;j++) {
          x= va*(ald.iso[j]);
            ald.diso[j] -= x;
        for (i=0;i<ib;i++) {
             ik=(j + i*lena);
                this->diso[ik] += x*pak[i];}
       }
}
template<size_t a> void tkk(Metab<N-2>& ald1, Metab<a>& ald2, ketose<a+2>& ket2,const double v) {
     int i,ii,j,ik,ib,lena1=this->len>>2, lena2=ald2.getlen();
     double x,vk, va,sumx=0.;
     const double *pak;
pak=&this->tk12[0]; ib=4; 
     vk=v/this->getcon();//kss; //vk /= (1+vk);
     ik=this->len; j=lena1-1;
         for (i=0;i<ik;i++) {ii=(i&j);
             x=this->iso[i]*vk;  
             sumx +=x;
             this->diso[i] -= x;   
             ald1.diso[ii] += x;
         }
    va= sumx/ald2.getcon();//suma;
    for(j=0;j<lena2;j++) {x= va*(ald2.iso[j]); ald2.diso[j] -= x;
        for (i=0;i<ib;i++) {ik=(j + i*lena2);
            ket2.diso[ik] += x*pak[i];    
            }
    }
}

template<size_t a> void tka(Metab<N-3>& ald1, Metab<a>& ald2, ketose<a+3>& ket2,const double v) {
     int i,ii,j,ik,ib,lena1=this->len>>3, lena2=ald2.getlen();
     double x,vk, va,sumx=0.;
     const double *pak;
        pak=&this->ta123[0]; ib=8; 
     vk=v/this->getcon();
     ik=this->len; j=lena1-1;
         for (i=0;i<ik;i++) {ii=(i&j);
             x=this->iso[i]*vk;  
             sumx +=x;
             this->diso[i] -= x;   
             ald1.diso[ii] += x;
         }
    va= sumx/ald2.getcon();
    for(j=0;j<lena2;j++) {x= va*(ald2.iso[j]); ald2.diso[j] -= x;
        for (i=0;i<ib;i++) {ik=(j + i*lena2);
            ket2.diso[ik] += x*pak[i];    
            }
    }
}
        ketose(){}
        ~ketose(){}
        };

class Ldistr {
	int ntime;
Metab_data<6> gl;
Metab_data<3> lac;
Metab_data<5> glu;
Metab_data<5> gln;
Metab_data<5> pro;
Metab_data<5> arg;
Metab_data<5> rna;
Metab_data<4> asp;
Metab_data<4> asn;
Metab_data<3> ala;
Metab_data<3> ser;
Metab_data<3> cys;
Metab_data<3> agl;
ketose<6> h6;
Metab<6> fbp;
Metab<3> t3;
ketose<7> s7;
Metab<3> pep;
Metab_data<3> pyr;
Metab_data<3> pyrm;
Metab_data<2> coa;
Metab_data<2> coac;
Metab_data<2> gly;
Metab<1> cthf;
Metab_data<4> oa;
Metab_data<4> oac;
Metab_data<6> cit;
Metab<6> citc;
Metab_data<5> akg;
Metab<5> akgc;
Metab_data<4> fum;
Metab_data<4> mal;
ketose<5> p5;
Metab<4> e4;
double tex[9],lacout,coaefl,tca,fpdh;
      void symm (double *s);
void csyn(double *coai,double *dcoai,double *oai,double *doai,double *dciti,const double v);
void split(double *h6,double *dh6,double *t1,double *dt1,const double vf,const double vr);
void spInvsl(double *h6,double *dh6,double *t1,double *dt1,const double vf,const double tsum);
void ast (double vf,double vr);

void sklad(int itime){gl.skladc(itime); lac.skladc(itime); gln.skladc(itime); lac.skladm0(itime); glu.skladm0(itime); ala.skladm0(itime); gly.skladm0(itime); ser.skladm0(itime); pro.skladm0(itime); cit.skladm0(itime); agl.skladm0(itime); asp.skladm0(itime);  fum.skladm0(itime); mal.skladm0(itime);}

void wrikin(std::ostringstream& so, int nt){
gl.wrikinc("Glc",so,nt); lac.wrikinc("Lac",so,nt); gln.wrikinc("Gln",so,nt); lac.wrikinm0("Lac",so,nt); glu.wrikinm0("Glu",so,nt); ala.wrikinm0("Ala",so,nt); gly.wrikinm0("Gly",so,nt); ser.wrikinm0("Ser",so,nt); pro.wrikinm0("Pro",so,nt); cit.wrikinm0("Cit",so,nt); agl.wrikinm0("Glr",so,nt); asp.wrikinm0("Asp",so,nt); fum.wrikinm0("Fum",so,nt); mal.wrikinm0("Mal",so,nt);}

       void setdiso(double *pyinit);
       void setiso(double *pyinit);
   void wrim0ex(std::ostringstream& fo);
void wriconex(std::ostringstream& fo);
void fitmet(double& xic,int iout,int iin,double fac);
double fitm(double& xic,int ipar,double fac);
double ser_gly (double v, double xthf);
double gly_ser (double v);
template<size_t l> void setmet(Metab<l>& met,data cmet[],data emet[][l+1],std::string sname,int vin,int vout);
template<size_t l> void setm0(Metab<l>& met,data cmet[],data emet[][l+1],std::string sname,int vin,int vout);
public:
       Metab<6> *met[3];
//       void setmet(){met[0]=&gl; met[1]=&gly;}
       int getmi(int met[],int& nmet,std::string smet[]);
    void setfige();
//       double setLacInit(double fact){return lac.setInCon(fact);}
       void read (char *finame, int ndat);
       void flback();
       int getN();
       void ssc(double *);
       void distr(double *py,double *pdydt);
       double label();
       void showmi(std::ostringstream& fo,int nt);
        double readExp(std::string fn);
        int diff(const double da,double st[], double *palpha) ;
        void show(std::ostringstream& fo,double xfin);
//        void showval(std::ostringstream& fo,double xfin);
        double xits(int its);
        void massfr();
        double integrbs();
	double ddisolve();
        int stor(double st[]) ;
	Ldistr(){}
	~Ldistr(void) {}
};

extern Ldistr horse;

//---------------------------------------------------------------------------
#endif
 
