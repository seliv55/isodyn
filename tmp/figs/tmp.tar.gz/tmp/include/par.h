//---------------------------------------------------------------------------
#ifndef PARH
#define PARH
// namespace parametry{}
class Par{
public:
       double val, delta, stor[2];
        Par(double v=0.):delta(v){}
        ~Par(){}
};
//---------------------------------------------------------------------------
#endif


