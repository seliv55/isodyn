extern const int hk, pfk, fbpase, t3pep, pept3, pk, pyrlac, lacpyr, pyrdcm, pyrdmc, pdh, citakg, akgfum, fumal, malfum, maloa, oamal, pc, malicm, malicc, ppp, oacd, mald, citdmc, citdcm, akgdmc, akgdcm, coaout, citakg1, akgcit1, gln_in, gln_out, gluin, gluout, t3ser, serpyr, asp_o, asp_i, ala_o, ala_i, r5_o, r5_i, cystin, proin, proout, kgin, coain, gln_pr, ser_pr, asp_pr, ala_pr, pro_pr, trpala, mthf, thf, sergly, glyser, cs0, D, atpase, resp, rald, rta, rtk, nrea;

extern const int aldf, aldrev, aldfli, aldi1, tafl, s7f6a, f6g3a, s7e4a, tkfl, s7p5, f6p5, p5f6, f6s7, s7f6, p5g3i, f6e4i, s7p5i, nflx;

extern const int nh6, nfbp, nt3, npep, npyr, npyrm, ncoa, ncoac, nagl, noa, noac, ncit, ncitc, nakg, nakgc, nfum, nmal, np5, ne4, ns7, ncthf, n_atp, n_nad, numx;

extern const int ngl, nlac, nglu, ngln, nala, nasp, nser, ngly, cthf, npro, nrna, nmet;

extern const int Nn;
extern const double thft;
extern double mader, dt,dif,dif0, suxx, Vi,Vt, mu, xx[], fluxes[], flx[],ystart[];
extern double nv1[],nv2[],xinit1[],xinit2[];
extern time_t ts,tf,tcal;
extern std::string foc, kin, fex1, fex2;
extern int ifn;
