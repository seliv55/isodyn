#include <iostream>
#include "nums.hh"
#include "tk.hh"
#include "nv.hh"
#include "modlab.h"
using namespace std;
void Ldistr::distr(double *py,double *pdydt) {
	double NOL=0.;
	setiso(py); setdiso(pdydt);
	for (int i=0;i<Nn;i++) pdydt[i]=0.;
	h6.sett(); t3.sett(); s7.sett(); p5.sett(); e4.sett(); 
	Problem.f(py,pdydt);
	Problem.ff(py,pdydt);
	Problem.fin(py);/**/
	double xthf=thft-cthf.sumt();
gl.input(h6,fluxes[hk]/gl.sumt(), 0.);
h6.input(fbp,fluxes[pfk], fluxes[fbpase]);
t3.input(pep,fluxes[t3pep], fluxes[pept3]);
pep.input(pyr,fluxes[pk], 0.);
pyr.input(lac,fluxes[pyrlac], fluxes[lacpyr]);
pyr.input(pyrm,fluxes[pyrdcm], fluxes[pyrdmc]);
pyrm.cutfirst(coa,fluxes[pdh]);
cit.icdh(akg,fluxes[citakg]);
akg.decarb(fum,fluxes[akgfum]);
fum.input(mal,fluxes[fumal], fluxes[malfum]);
mal.input(oa,fluxes[maloa], fluxes[oamal]);
pyrm.carb(oa,fluxes[pc]);
mal.decarb(pyrm,fluxes[malicm]);
oac.decarb(pyr,fluxes[malicc]);
h6.cutfirst(p5,fluxes[ppp]);
oac.input(mal,fluxes[oacd], fluxes[mald]);
cit.input(citc,fluxes[citdmc], fluxes[citdcm]);
akg.input(akgc,fluxes[akgdmc], fluxes[akgdcm]);
citc.liase(oac,coa,fluxes[coaout]);
citc.icdh(akgc,fluxes[citakg1]);
akgc.icdhr(citc,fluxes[akgcit1]);
gln.input(akgc,fluxes[gln_in], fluxes[gln_out]);
glu.input(akgc,fluxes[gluin], fluxes[gluout]);
t3.input(ser,fluxes[t3ser], 0.);
ser.input(pyrm,fluxes[serpyr], 0.);
oac.input(asp,fluxes[asp_o], fluxes[asp_i]);
pyr.input(ala,fluxes[ala_o], fluxes[ala_i]);
p5.input(rna,fluxes[r5_o], fluxes[r5_i]);
pyrm.diso[0]+=fluxes[cystin];
pro.input(akgc,fluxes[proin], fluxes[proout]);
akg.diso[0]+=fluxes[kgin];
coa.diso[0]+=fluxes[coain];
gln.output(fluxes[gln_pr]);
ser.output(fluxes[ser_pr]);
asp.output(fluxes[asp_pr]);
ala.output(fluxes[ala_pr]);
pro.output(fluxes[pro_pr]);
ala.diso[0]+=fluxes[trpala];
ser_gly(xthf,fluxes[sergly]);
gly_ser(fluxes[glyser]);
csyn(coa.iso,coa.diso,oa.iso,oa.diso,cit.diso,fluxes[cs0]);
split(fbp.iso,fbp.diso,t3.iso,t3.diso,fluxes[aldf],fluxes[aldf+1]);
spInvsl(fbp.iso,fbp.diso,t3.iso,t3.diso,fluxes[aldf+2],t3.sumt());
	h6.tka<4>(t3,e4,s7,fluxes[tafl]);
	s7.tka<3>(e4,t3,h6,fluxes[tafl+1]);
	h6.invista(t3,fluxes[tafl+2]);
	s7.invista(e4,fluxes[tafl+3]);
p5.tkk<5>(t3,p5,s7,fluxes[tkfl]);
s7.tkk<3>(p5,t3,p5,fluxes[tkfl+1]);
h6.tkk<3>(e4,t3,p5,fluxes[tkfl+2]);
p5.tkk<4>(t3,e4,h6,fluxes[tkfl+3]);
h6.tkk<5>(e4,p5,s7,fluxes[tkfl+4]);
s7.tkk<4>(p5,e4,h6,fluxes[tkfl+5]);
p5.invistk(t3,fluxes[tkfl+6]);
h6.invistk(e4,fluxes[tkfl+7]);
s7.invistk(p5,fluxes[tkfl+8]);
	gl.volume(Vt);
	lac.volume(Vt);
	glu.volume(Vt);
	gln.volume(Vt);
	ala.volume(Vt);
	ser.volume(Vt);
	rna.volume(Vt);
	asp.volume(Vt);
	pro.volume(Vt);
	gly.volume(Vt);
	cthf.volume(Vt);
	symm(fum.getisot());
xx[ngl]=gl.sumt(); xx[nlac]=lac.sumt(); xx[nglu]=glu.sumt(); xx[ngln]=gln.sumt(); xx[nala]=ala.sumt(); xx[nser]=ser.sumt(); xx[nrna]=rna.sumt(); xx[nasp]=asp.sumt(); xx[npro]=pro.sumt(); xx[ngly]=gly.sumt(); xx[ncthf]=cthf.sumt(); xx[nh6]=h6.sumt(); xx[nfbp]=fbp.sumt(); xx[nt3]=t3.sumt(); xx[ns7]=s7.sumt(); xx[npep]=pep.sumt(); xx[npyr]=pyr.sumt(); xx[npyrm]=pyrm.sumt(); xx[ncoa]=coa.sumt(); xx[noa]=oa.sumt(); xx[noac]=oac.sumt(); xx[ncit]=cit.sumt(); xx[ncitc]=citc.sumt(); xx[nakg]=akg.sumt(); xx[nakgc]=akgc.sumt(); xx[nfum]=fum.sumt(); xx[nmal]=mal.sumt(); xx[np5]=p5.sumt(); xx[ne4]=e4.sumt(); 
}
