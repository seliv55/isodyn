#include <iostream>
#include <cmath>
#include "nums.hh"
#include "tk.hh"
#include "nv.hh"
#include "modlab.h"
using namespace std;
double Vi, xribi, xasp=1.,mu;
double Ldistr::readExp (string fn) {
string aaa;  ifstream fi(fn.c_str()); double Ti,ts1;  mu=0.; fi>> dt; getline(fi,aaa);
tex[0]=0.;  for(ntime=1;;ntime++) {fi>>tex[ntime]; tex[ntime] *= 60.; if(tex[ntime]<0) break;}
fi>> Vi; getline(fi,aaa); double Nc[ntime]; for(int i=0;i<ntime;i++) fi>>Nc[i]; getline(fi,aaa);
for(int i=1;i<ntime;i++) mu += log(Nc[i]/Nc[0])/tex[i];
 mu /= ((double)(ntime-1)*1.0); getline(fi,aaa);
	gl.readc(fi,ntime); xx[ngl]=gl.getconc()[0].mean;
	lac.readc(fi,ntime); xx[nlac]=lac.getconc()[0].mean;
	 xx[nglu]=0.1; glu.setconc(xx[nglu]);
	 xx[ngln]=4.9; gln.setconc(xx[ngln]);
	 xx[nala]=0.4; ala.setconc(xx[nala]);
	 xx[ngly]=0.4; gly.setconc(xx[ngly]);
	 xx[nser]=0.4; ser.setconc(xx[nser]);
	 xx[nasp]=0.0001; asp.setconc(xx[nasp]);
	 xx[npro]=0.0001; pro.setconc(xx[npro]);
	 xx[ncthf]=0.5;	
gl.read(fi,ntime);//	 cout<<"exper="<<gl.getexper(0)[6].mean <<endl;
gln.read(fi,ntime);
glu.read(fi,ntime);
pyrm.read(fi,ntime);
//ala.read(fi,ntime);
//gly.read(fi,ntime);
//ser.read(fi,ntime);
//pro.read(fi,ntime);
//cys.read(fi,ntime);
//rna.read(fi,ntime);
cit.read(fi,ntime);
agl.read(fi,ntime);
asp.read(fi,ntime);
//asn.read(fi,ntime);
//arg.read(fi,ntime);
//oac.read(fi,ntime);
fum.read(fi,ntime);
mal.read(fi,ntime);
//coac.read(fi,ntime);
fi.close();
return ts1;}
