#!/bin/bash
pkill beas.out
rm nohup.out *~ */*~
./beas.out .
./limpiar.out 
