//---------------------------------------------------------------------------
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>

//---------------------------------------------------------------------------
using namespace std;
string partk="e0tk", parta="e0ta", ssym="fum";
string setk1, seta1, setald1;

inline string mm(string fln, string *sub, int nsub, ostringstream& parsets, bool ff=0){ //cout<<sub[i]<<'\n';
    string sfl="flx["+fln+"]", sub1="",ssub="", sdx="", foo =sfl+"= ";
     if(ff) foo += "rea[D].v()*"; int typv(0);
 for(int i=0;i<nsub;i++){ sub1=sub[i];
  if(sub1.at(0)=='-') if(sub1.size()>1){if(sub1.at(1)=='n') ssub +=", y["+sub1.erase(0,1)+"]";
                       else ssub +=", "+sub1.erase(0,1); typv++;}}
      parsets<<fln<<" "<<typv+1<<" v0= 0.01 ";
       for(int i=0;i<typv;i++) parsets<<"K"<<i<<"= 0.01 "; parsets<<'\n';
    ssub=ssub.erase(0,1);
      foo +="rea["+fln+"].v("+ssub+"); "; ssub="";
 for(int i=0;i<nsub;i++){ sub1=sub[i];
  if(sub1.at(0)=='-') {if(sub1.size()>1){if(sub1.at(1)=='n') ssub +="dydx["+sub1.erase(0,1)+"] -= "+sfl+";  ";}}
   else ssub +="dydx["+sub1+"] += "+sfl+";  ";
  }
         while(foo.length()<51) foo +=" "; foo +=ssub+'\n'; 
return foo;}


inline string ald(ostringstream& parset,string aldfl,string alds,string aldp){ 
    string sfl="flx["+aldfl+"]"; parset<<"ald   1  V= 0.00693115  K1= 14870\n";
          setald1 ="aldolase.st1fl(&"+sfl+", y[n"+alds+"], y[n"+aldp+"]);"; string foo=setald1;
      while(foo.length()<51) foo +=" ";  foo +="dydx[n"+alds+"] -= "+sfl+";";
      while(foo.length()<80) foo +=" ";  foo +="dydx[n"+aldp+"] += 2.*"+sfl+";\n";     
return foo;}

inline string ta(ostringstream& parset,string tafl,string tak1,string taa1,string taa2,string tak2){ 
    string sfl="flx["+tafl+"]"; parset<<"ta   4  v0= 0.000113773  K1= 1.45  K2= 1.6456  K3= 0.010418  K4= 0.544787\n";
      seta1 ="ta.st1fl(&"+sfl+", y[n"+tak1+"]/fh6, y[n"+taa1+"]/ft3, y[n"+taa2+"], y[n"+tak2+"]);"; string foo=seta1;
      foo +="\n\t\t\t\tdydx[n"+tak1+"] -= "+sfl+";\t dydx[n"+taa1+"] += "+sfl+";";
      foo +="\n\t\t\t\tdydx[n"+taa2+"] -= "+sfl+";\t dydx[n"+tak2+"] += "+sfl+";\n";    
return foo;}

inline string tk(ostringstream& parset,string tkfl,string tka1,string tkk1,string tka2,string tkk2,string tka3,string tkk3){ 
    string sfl="flx["+tkfl+"]", sfl1="flx["+tkfl+"+1]", sfl2="flx["+tkfl+"+2]"; 
    parset<<"tk   6  V= 1.29301e-07  K1= 0.03  K2= 2  K3= 3  K4= 1.63335  K5= 3  K6= 11\n";
  setk1="tk.st1fl(&"+sfl+", y[n"+tka1+"]/ft3, y[n"+tkk1+"], y[n"+tka2+"], y[n"+tkk2+"]/fh6, y[n"+tka3+"], y[n"+tkk3+"]);";
     string foo=setk1+"\n\t\t\t\tdydx[n"+tkk1+"] -= "+sfl+";\tdydx[n"+tka1+"] += "+sfl+";\n"; 
      foo +="\t\t\t\tdydx[n"+tkk3+"] -= "+sfl1+";\tdydx[n"+tka3+"] += "+sfl1+";\n";    
      foo +="\t\t\t\tdydx[n"+tkk2+"] -= "+sfl2+";\tdydx[n"+tka2+"] += "+sfl2+";\n";    
return foo;}

inline string listint(string sname[],int inum,string sfin,string sin="0"){
  string aaa="const int "+sname[0]+"="+sin+", ";
   for(int i=1;i<inum;i++)   aaa+=sname[i]+"="+sname[i-1]+"+1, ";
     aaa+=sfin+"="+sname[inum-1]+"+1;\n\n";
 return aaa;}
inline string listname(string sname[],int inum,string sfin){
  string aaa="extern const int ";
   for(int i=0;i<inum;i++)   aaa+=sname[i]+", ";   aaa+=sfin+";\n\n";
 return aaa;}
  inline string setvals(string snames[],int nelem, string sval){ string aaa="";
    for(int i=0;i<nelem;i++) {ostringstream snum; snum<<i; aaa+=snum.str()+") "+snames[i]+"\t"+sval+"\n";}
      return aaa;}

int main ( int argc, char *argv[] ) {
   ifstream fi("model");  int kfl, knkin, intra, iextra, kiso;
     string aaa="", stri, siso;
// variables of kinetic model   
       vector<string> stype, newkin, newiso, edata, xi;// metabolite type, name, edata(conc,lab,0), chi(yes,no)
         getline(fi,aaa); getline(fi,aaa);
   for(int i=0; ;i++) {
    fi>> aaa; if(aaa.substr(0,3)=="fin") break; if(aaa!="0") stype.push_back(aaa);//type of metabolite
    fi>> aaa; newkin.push_back(aaa);//names/numbrs of metabolites
    fi>> aaa; edata.push_back(aaa);//names/numbrs of metabolites
    fi>> aaa; xi.push_back(aaa);//names/numbrs of metabolites
   }
//reding the scheme of the model:
       fi>>aaa>>kfl;//number og reactions
        getline(fi,aaa); getline(fi,aaa);
       
     string flname[kfl], fladd[18], prod[kfl], isos[kfl], isop[kfl], isom[kfl], revfl[kfl];
     int numsub, eq;
//     nv.cpp:
  string f_ff="void Fit::f(const double *y,double *dydx) {\n\tfor(int i=0;i<numx;i++) dydx[i]=0.;\n\t for(int i=0;i<nflx;i++) flx[i]=0.;\n\t double amp = -(sqrt(4.*xx[n_atp]*tan-3.*xx[n_atp]*xx[n_atp])-2.*tan+xx[n_atp])/2.;\n\t double a_dp = (sqrt(xx[n_atp])*sqrt(4.*tan-3.*xx[n_atp])-xx[n_atp])/2.;\n\t double h_nad = tnad-xx[n_nad];\n\t xthf=thft-xx[ncthf];\n";// functions f & ff
  string flfor="void Parray::flfor(double *y){\nfor(int i=0;i<nflx;i++) fluxes[i] = flx[i] * dt/Vi;\n";// function flfor
    ostringstream parsets;
   for(int i=0;i<kfl;i++){ fi>>aaa>> flname[i]>>numsub; string subst[numsub]; //substrates
           string s_fl ="fluxes["+flname[i]+"] /= "; string sy=""; int is(0);
     for(int i1=0;i1<numsub;i1++){  fi>>subst[i1];                            //read substrates
      if(subst[i1].at(0)=='-')if(subst[i1].size()>2)if(subst[i1].at(2)!='_'){ is++;
      if(is>1) s_fl +="*";
      sy=subst[i1]; sy.erase(0,1); if(sy.at(0)=='n') s_fl +="y["; s_fl +=sy; if(sy.at(0)=='n') s_fl +="]";}
     }    if(sy.size()>2) flfor +=s_fl+";\n"; 
    fi>>eq>>isos[i]>>isop[i]>>isom[i]>>revfl[i]; parsets<<i<<" ";
       f_ff += mm(flname[i],subst,numsub,parsets,eq); // function f
         }

                                          int ifl=0; 
     string aldfl, alds, aldp;
   fi>>aaa>>aldfl>>alds>>aldp;//aldolase
      f_ff += ald(parsets,aldfl, alds, aldp); fladd[ifl]=aldfl; ifl++;  fladd[ifl]="aldrev"; ifl++;
                                          fladd[ifl]="aldfli"; ifl++;  fladd[ifl]="aldi1"; ifl++;
                                          flfor +="fluxes["+aldfl+"] /= xx[n"+ alds+ "];\n";
                                          flfor +="fluxes["+aldfl+"+1] /= (xx[n"+ aldp+ "]*xx[n"+ aldp+ "]);\n";
                                          flfor +="fluxes["+aldfl+"+2] /= xx[n"+ alds+ "];\n";
    cout<<"aldfl="<<aldfl<<endl;
     string tafl, tak1,taa1,taa2,tak2;
   fi>>aaa>>tafl>>tak1>>taa1>>taa2>>tak2;//transaldolase
      f_ff += ta(parsets,tafl, tak1,taa1,taa2,tak2); fladd[ifl]=tafl; ifl++; fladd[ifl]="s7f6a";ifl++;
                                                   fladd[ifl]="f6g3a"; ifl++; fladd[ifl]="s7e4a"; ifl++;
   
     string tkfl, tka1,tkk1,tka2,tkk2,tka3,tkk3;
   fi>>aaa>>tkfl>>tka1>>tkk1>>tka2>>tkk2>>tka3>>tkk3;//transketoolase
      f_ff += tk(parsets,tkfl, tka1,tkk1,tka2,tkk2,tka3,tkk3); fladd[ifl]=tkfl; ifl++;
      fladd[ifl]="s7p5"; ifl++; fladd[ifl]="f6p5"; ifl++; fladd[ifl]="p5f6"; ifl++; fladd[ifl]="f6s7"; ifl++;
     fladd[ifl]="s7f6"; ifl++; fladd[ifl]="p5g3i"; ifl++; fladd[ifl]="f6e4i"; ifl++; fladd[ifl]="s7p5i"; ifl++;
               f_ff+="}\n\n"; flfor+="}\n\n";
   
          int nex; fi>>aaa>>nex; cout<<aaa<<" "<<nex<<'\n'; 
          f_ff+="void Fit::ff(const double *y,double *dydx) {\n";
          string smet[nex]; int numfl;
       for(int i=0;i<nex;i++){fi>>smet[i]; f_ff+="\tdydx["+smet[i]+"] = "; 
       fi>>numfl; string sflux; for(int i=0;i<numfl;i++) {fi>>sflux; 
        if(sflux.at(0)=='-') {f_ff+="- "; sflux.erase(0,1);} else f_ff+="+"; f_ff+="flx["+sflux+"]";}
         f_ff+=";\n";
       }  f_ff+="}\n\n";
       
       getline(fi,aaa);  getline(fi,aaa); 
       fi>>aaa>>iextra>>aaa>>intra; kiso=intra+iextra; int ncarb[kiso]; cout<<"kiso="<<kiso<<endl;
     string stype[kiso],  newiso[kiso], edata[kiso], xi[kiso];// read iso: type,name, edata(conc,lab,0), chi(yes,no)
   for(int i=0;i<kiso;i++) {fi>>aaa>>stype[i]>>newiso[i]>>edata[i]>>xi[i]; ncarb[i]=atoi(stype[i].substr(stype[i].size()-2,1).c_str());}
         fi.close();
         
//setting ODE model, conversion of fluxes for iso model (flfor):
      
//                                          flname[ifl]=csfl[1]; ifl++;
               
//declaration of the list of fluxes and variables for "nums.hh"
  ofstream numshh("../include/nums.hh");
  string hlfl=listname(flname,kfl,"nrea")+listname(fladd,ifl,"nflx");   hlfl+=listname(newkin,knkin,"numx")+listname(smet,nex,"nmet"); 
     hlfl+="extern const int Nn;\nextern const double thft;\n";
     hlfl+="extern double mader, dt,dif,dif0, suxx, Vi,Vt, mu, xx[], fluxes[], flx[],ystart[];\n";
     hlfl+="extern double nv1[],nv2[],xinit1[],xinit2[];\nextern time_t ts,tf,tcal;\n";
     hlfl+="extern std::string foc, kin, fex1, fex2;\nextern int ifn;\n";
                                  numshh<<hlfl; numshh.close();
 //file with parameters values
               parsets<<"1 3 5 7 9 11 -1\n"+setvals(newkin,knkin, "0.01")+setvals(flname,ifl, "0.001");
      ofstream param("parameters");
  param<<parsets.str(); param.close();
    
string nvcpp="#include <iostream>\n#include \"nr.h\"\n#include \"nums.hh\"\n#include \"tk.hh\"\n#include \"nv.hh\"\n#include \"modlab.h\"\n#include \"solvers.h\"\n#include \"analis.h\"\n";
 nvcpp += "using namespace std;\n";
//definition of the list of fluxes, parameters and variables for "nv.cpp"
 nvcpp +=listint(flname,kfl,"nrea")+listint(fladd,ifl,"nflx","nrea") + listint(newkin,knkin,"numx")+listint(smet,nex,"nmet","numx");
  nvcpp+=("\tFit Problem;\n\tconst double thft(1.);\n\tdouble dt,xx[nmet],flx[nflx],fluxes[nflx];\n\tdouble xm0, xinit1[nmet],xinit2[nmet];\n\t");
  nvcpp +="int Parray::par[nrea]; string Parray::namef[nflx], Parray::namex[nmet];\n\tReapar Parray::rea[nrea];\n\tdouble Analis::nv1[nrea], Analis::nv2[nrea];\n"+f_ff;
  nvcpp +="void Parray::init(){ft3=10.; fh6=7.;\n\ttk.setk(rea[rtk].getpar());\n\tta.setk(rea[rta].getpar());\n\taldolase.setk(rea[rald].getpar());}\n";
  nvcpp +="void Parray::fin(double y[]){\n\t"+setald1+"\n\t"+setk1+"\n\t"+seta1+"\n\t";
  setald1[11]='2'; setk1[5]='2'; seta1[5]='2';
                                    nvcpp +=setald1+"\n\t"+setk1+"\n\t"+seta1+"\nflfor(y);\n}\n"+flfor;
  ofstream fout("../con512tpl/nv.cpp"); fout<<nvcpp;   fout.close(); nvcpp="";

 //distr.cpp - begin   
   string sdist="#include <iostream>\n#include \"nums.hh\"\n#include \"tk.hh\"\n#include \"nv.hh\"\n#include \"modlab.h\"\n";
 sdist += "using namespace std;\nvoid Ldistr::distr(double *py,double *pdydt) {\n\tdouble NOL=0.;\n\tsetiso(py); setdiso(pdydt);\n\t";
 sdist += "for (int i=0;i<Nn;i++) pdydt[i]=0.;\n\t";
  for(int i=iextra;i<kiso;i++) if(stype[i].substr(0,3)=="ald") sdist+=newiso[i]+".sett(); ";
                            else if(stype[i].substr(0,3)=="ket") sdist+=newiso[i]+".sett(); "; sdist+="\n";
   sdist += "\tProblem.f(py,pdydt);\n\tProblem.ff(py,pdydt);\n\tProblem.fin(py);/**/\n\tdouble xthf=thft-cthf.sumt();\n";
     for(int i=0;i<kfl;i++) { if(isos[i]!="0"){
            if(isos[i][0]=='/') sdist +=isos[i].substr(1)+isom[i]+isop[i]+",fluxes["+flname[i]+"]/"+isos[i].substr(1)+".sumt()";
               else if(isop[i]!="0") sdist +=isos[i]+isom[i]+isop[i]+",fluxes["+flname[i]+"]";
           if(revfl[i]!="0") {if(revfl[i]!="NOL") sdist += ", fluxes["+revfl[i]+"]"; else sdist += ", 0.";}
           else if(isop[i]=="0") sdist +=isos[i]+isom[i]+"fluxes["+flname[i]+"]";
                               sdist +=");\n";}
                  else if(isop[i]!="0") sdist += isop[i]+".diso[0]+=fluxes["+flname[i]+"];\n";}
    sdist +="csyn(coa.iso,coa.diso,oa.iso,oa.diso,cit.diso,fluxes[cs0]);\n";
//    sdist +="csyn("+ics1[1]+".iso,"+ics1[1]+".diso,"+ics2[1]+".iso,"+ics2[1]+".diso,"+icsp[1]+".diso,fluxes["+csfl[1]+"]);\n";
    sdist +="split("+alds+".iso,"+alds+".diso,"+aldp+".iso,"+aldp+".diso,fluxes["+aldfl+"],fluxes["+aldfl+"+1]);\n";
    sdist +="spInvsl("+alds+".iso,"+alds+".diso,"+aldp+".iso,"+aldp+".diso,fluxes["+aldfl+"+2],"+aldp+".sumt());\n\t";

    sdist +=tak1+".tka<"+taa2.substr(1)+">("+taa1+","+taa2+","+tak2+",fluxes["+tafl+"]);\n\t";
    sdist +=tak2+".tka<"+taa1.substr(1)+">("+taa2+","+taa1+","+tak1+",fluxes["+tafl+"+1]);\n\t";
    sdist +=tak1+".invista("+taa1+",fluxes["+tafl+"+2]);\n\t";
    sdist +=tak2+".invista("+taa2+",fluxes["+tafl+"+3]);\n";
    
    sdist +=tkk1+".tkk<"+tka3.substr(1)+">("+tka1+","+tka3+","+tkk3+",fluxes["+tkfl+"]);\n";
    sdist +=tkk3+".tkk<"+tka1.substr(1)+">("+tka3+","+tka1+","+tkk1+",fluxes["+tkfl+"+1]);\n";
    sdist +=tkk2+".tkk<"+tka1.substr(1)+">("+tka2+","+tka1+","+tkk1+",fluxes["+tkfl+"+2]);\n";
    sdist +=tkk1+".tkk<"+tka2.substr(1)+">("+tka1+","+tka2+","+tkk2+",fluxes["+tkfl+"+3]);\n";
    sdist +=tkk2+".tkk<"+tka3.substr(1)+">("+tka2+","+tka3+","+tkk3+",fluxes["+tkfl+"+4]);\n";
    sdist +=tkk3+".tkk<"+tka2.substr(1)+">("+tka3+","+tka2+","+tkk2+",fluxes["+tkfl+"+5]);\n";
    sdist +=tkk1+".invistk("+tka1+",fluxes["+tkfl+"+6]);\n";
    sdist +=tkk2+".invistk("+tka2+",fluxes["+tkfl+"+7]);\n";
    sdist +=tkk3+".invistk("+tka3+",fluxes["+tkfl+"+8]);\n\t";
    for(int i=0;i<iextra;i++) sdist +=newiso[i]+".volume(Vt);\n\t";
                     sdist +="symm("+ssym+".getisot());\n";
    for(int i=0;i<kiso;i++) sdist += "xx[n"+newiso[i]+"]="+newiso[i]+".sumt(); ";sdist += "\n}\n";
 fout.open("../con512tpl/distr.cpp"); fout<<sdist;  fout.close(); sdist="";
 
 //readexp.cpp -begin                                     
// aaa="#include <iostream>\n#include <cmath>\n#include \"nums.hh\"\n#include \"tk.hh\"\n#include \"nv.hh\"\n#include \"modlab.h\"\n";
// aaa += "using namespace std;\ndouble Vi, xribi, xasp=1.,mu;\ndouble Ldistr::readExp (string fn) {\n";
// aaa +="string aaa;  ifstream fi(fn.c_str()); double Ti,ts1;  mu=0.; fi>> dt; getline(fi,aaa);\n";
// aaa +="tex[0]=0.;  for(ntime=1;;ntime++) {fi>>tex[ntime]; tex[ntime] *= 60.; if(tex[ntime]<0) break;}\n";
// aaa +="fi>> Vi; getline(fi,aaa); double Nc[ntime]; for(int i=0;i<ntime;i++) fi>>Nc[i]; getline(fi,aaa);\n";
// aaa +="for(int i=1;i<ntime;i++) mu += log(Nc[i]/Nc[0])/tex[i]; mu/=1.;\n mu /= (double)(ntime-1); getline(fi,aaa);\n";
// for(int i=0;i<kiso;i++) if(edata[i][0]=='c') aaa +="\t"+newiso[i]+".readc(fi,c"+newiso[i]+",ntime);\n";
// for(int i=0;i<kiso;i++) if(edata[i][1]=='l') {int j=edata[i].length();
//       if(j==2) aaa +=newiso[i]+".read(fi,f"+newiso[i]+",ntime,e"+newiso[i]+");\n";
//    else {if(j>2) {sdist=newiso[i]+edata[i].substr(2,2); aaa +=newiso[i]+".read(fi,f"+sdist+",ntime,e"+sdist+");\n";}
//       if(j>4) {sdist=newiso[i]+edata[i].substr(4,2); aaa +=newiso[i]+".read(fi,f"+sdist+",ntime,e"+sdist+");\n";}}
//                      }
//                aaa +="fi.close();\nreturn ts1;}\n";
// fout.open("../con512tpl/readexp.cpp"); fout<<aaa; fout.close();

//functions for "lab.cpp":
  string labcpp="#include <iostream>\n#include \"nr.h\"\n#include \"nums.hh\"\n#include \"modlab.h\"\n";
   labcpp+="using namespace std;\n\nint Ldistr::getN() {\n"+newiso[0]+".ny=nmet;\n";
    for(int i=1;i<kiso;i++) labcpp+=newiso[i]+".ny="+newiso[i-1]+".ny+"+newiso[i-1]+".getlen();\n";
                  labcpp+="return ("+newiso[kiso-1]+".ny+"+newiso[kiso-1]+".getlen());\n}\n\n";

      labcpp+="void Ldistr::setdiso(double *pyinit) {\n"+newiso[0]+".diso= &pyinit["+newiso[0]+".ny];\n";
    for(int i=1;i<kiso;i++) labcpp +=newiso[i]+".diso= &pyinit["+newiso[i]+".ny];\n"; labcpp+="}\n\n";

     labcpp+="void Ldistr::setiso(double *pyinit) {\n"+newiso[0]+".iso= &pyinit["+newiso[0]+".ny];\n";
        for(int i=1;i<kiso;i++) labcpp +=newiso[i]+".iso= &pyinit["+newiso[i]+".ny];\n";   labcpp+="}\n\n";

  labcpp +="void Ldistr::massfr() {\n";
   for(int i=0;i<kiso;i++) if((edata[i][0]=='c')||(edata[i][0]=='l')) labcpp +=newiso[i]+".percent(); ";
      labcpp +="}\n\n";
      
  labcpp +="double Ldistr::xits(int its) {int itp=its-1; double xi=0;\n";
   for(int i=0;i<kiso;i++) {
       if(edata[i][0]=='c') labcpp += "xi += "+newiso[i]+".chicon(its);\n";
       if(edata[i][1]=='l'){
       if(xi[i].size()==1) labcpp += "xi += "+newiso[i]+".chisq(its);\n";
       else if(xi[i].size()>1) labcpp += "xi += "+newiso[i]+".chisqsum("+xi[i]+",its);\n";
       }
   }
     labcpp += "return xi;}\n\n";
     
     labcpp +="void Ldistr::show(ostringstream& fo,double xfin) { fo<<setw(5)<<xfin;\n";
      aaa="//t=1; "; string bbb="t";
    for(int i=0;i<kiso;i++) {
     if(edata[i][0]=='c') {labcpp +=newiso[i]+".showcon(fo); ";aaa+="c"+newiso[i]+"="+bbb+"+1; "; bbb="c"+newiso[i];}
      if(xi[i]=="1") { labcpp +=newiso[i]+".showm0(fo); ";aaa+=newiso[i]+"="+bbb+"+1; "; bbb=newiso[i];}
     else if(xi[i].size()>2){labcpp+=newiso[i]+".showsum("+xi[i]+",fo); ";aaa+="s"+newiso[i]+"="+bbb+"+1; ";bbb="s"+newiso[i];}
      }
             labcpp +="fo<<\"\\n\";}\n"+aaa+"\n"; aaa="";
             
    labcpp +="double Ldistr::label() {\nreturn (";
    for(int i=iextra;i<kiso;i++) labcpp +=newiso[i]+".sumt()+";
       labcpp.erase(labcpp.end()-1); labcpp+=");}\n\n";
    labcpp+="void Ldistr::flback(){ cout<<\" ∑isotopomers-variable:\"<<\"\\n\";\ncout";
    for(int i=iextra;i<kiso;i++) labcpp+="<<\" "+newiso[i]+"=\"<<"+newiso[i]+".sumt()<<\"-\"<<xx[n"+newiso[i]+"]";
                           labcpp+="<<\"\\n\";}\n\n";
 fout.open("../con512tpl/lab.cpp"); fout<<labcpp; fout.close(); labcpp="";/**/
     
//    siso="#include <iostream>\n#include \"nums.hh\"\n#include \"modlab.h\"\nusing namespace std;\n";
//                                        siso+="void Ldistr::ssc(double *pyinit) {setiso(pyinit);\n";
//    for(int i=0;i<iextra;i++) if(edata[i][0]=='c') siso+=newiso[i]+".set0(c"+newiso[i]+"[0].mean);\n";
//                              else siso+=newiso[i]+".set0(0.1);\n";
//        siso+="gln.iso[0]=cgln[0].mean*egln[0][0].mean;\ngln.iso[31]=cgln[0].mean*egln[0][5].mean;\n";
//        siso+="gl.iso[0]=cgl[0].mean*egl[0][0].mean;\ngl.iso[48]=cgl[0].mean*egl[0][2].mean;\n";
//        siso+="gl.iso[49]=cgl[0].mean*egl[0][3].mean/4.;\ngl.iso[50]=gl.iso[49];\ngl.iso[52]=gl.iso[49];\n";
//        siso+="gl.iso[56]=gl.iso[49];\ngl.iso[51]=cgl[0].mean*egl[0][4].mean/6.;\ngl.iso[53]=gl.iso[51];\n";
//        siso+="gl.iso[54]=gl.iso[51];\ngl.iso[57]=gl.iso[51];\ngl.iso[58]=gl.iso[51];\ngl.iso[60]=gl.iso[51];\n";
//     for(int i=iextra;i<kiso;i++) siso+=newiso[i]+".set0(xx[n"+newiso[i]+"]);\n";
//                  siso+="}\n\n";
// fout.open("../con512tpl/ssc.cpp");    fout<<siso; fout.close();/**/

  
        stri= "";   for(int i=0;i<kiso;i++) stri += stype[i]+" "+newiso[i]+";\n";
       aaa="data "; for(int i=0;i<iextra;i++) if(edata[i][0]=='c') aaa +="c"+newiso[i]+"[tt],";
 for(int i=0;i<kiso;i++) if(edata[i][1]=='l') {int j=edata[i].size(); 
      int a=1+ncarb[i]; ostringstream ao; ao<<a;
       if(j==2) aaa +="e"+newiso[i]+"[tt]["+ao.str()+"],";
        else {if(j>2) {sdist=newiso[i]+edata[i].substr(2,2); aaa +="e"+sdist+"[tt]["+ao.str()+"],";}
             if(j>4) {sdist=newiso[i]+edata[i].substr(4,2); aaa +="e"+sdist+"[tt]["+ao.str()+"],";}}
                      }
                      aaa[aaa.size()-1]=';';   aaa +="\ndouble ";
    for(int i=0;i<iextra;i++) if(edata[i][0]=='c') aaa +="xic"+newiso[i]+"[tt],";
 for(int i=0;i<kiso;i++) if(edata[i][1]=='l') {int j=edata[i].size(); 
       if(j==2) aaa +="xi"+newiso[i]+"[tt],";
        else {if(j>2) {sdist=newiso[i]+edata[i].substr(2,2); aaa +="xi"+sdist+"[tt],";}}
                      }
                      aaa[aaa.size()-1]=';';   aaa +="\nint ";
 for(int i=0;i<kiso;i++) if(edata[i][1]=='l') {int j=edata[i].size(); 
       if(j==2) aaa +="f"+newiso[i]+",";
        else {if(j>2) {sdist=newiso[i]+edata[i].substr(2,2); aaa +="f"+sdist+",";}}
                      }
                      aaa[aaa.size()-1]=';';   aaa +="\n";
 fout.open("output"); fout<<stri<<aaa;  fout.close();
        return 0;}

