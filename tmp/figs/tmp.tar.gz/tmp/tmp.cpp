#include <iostream>
using namespace std;

int main ( int argc, char *argv[] ) {
//const char* b=a.c_str();
//x += atoi(y);  // Use the integer equivalent of char / string  y;
const int b[]={1,2,5,18}, *ii[2]; ii[0]=b;
cout << ii[0][2] << endl;
int i(0);i++ ++;
cout<<i<<endl;
return 0;}
